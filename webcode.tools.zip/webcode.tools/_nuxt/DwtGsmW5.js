import {_ as a} from "./CgCn6qVr.js";
import {_ as i} from "./BJI5yTQ7.js";
import {_} from "./BTZ45fU4.js";
import {u as l} from "./DPMsOK0k.js";
import {d as m, o as c, i as d, a as e, w as t, h as o} from "./t-Ic3Q-i.js";
const p = o("h1", null, "CSS Generator", -1)
  , u = o("p", null, " Generate highly customizable CSS properties. Preview the results before copying them to your website. ", -1)
  , y = m({
    __name: "index",
    setup(f) {
        return l({
            title: "CSS Code Generator for Effortless Web Development",
            meta: [{
                name: "description",
                content: "Easily generate CSS code with our user-friendly CSS generator. Streamline web development and design with our intuitive tool."
            }]
        }),
        (h, S) => {
            const n = a
              , r = i
              , s = _;
            return c(),
            d("div", null, [e(n, null, {
                default: t( () => [p, u]),
                _: 1
            }), e(s, null, {
                default: t( () => [e(r, {
                    module: "css"
                })]),
                _: 1
            })])
        }
    }
});
export {y as default};